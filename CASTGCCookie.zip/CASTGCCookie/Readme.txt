Step One
	- Create a java class with your cookie name inside the directory of 
	  (src\main\java\org\wso2\carbon\connector\cookie\headers)
Step Two
	- Build a maven project in the Home directory using "mvn clean install" command
	- You can find the jar file inside the \target directory
Step Three
	- Copy the jar file and add it into the "wso2mi-4.1.0\lib" directory

Step four
	- Add below configurations in your codebase 
		
		<property name="cookie-action"
                   value="get-transport"
                   scope="default"
                   type="STRING"/>
		<class name="org.wso2.carbon.connector.cookie.headers.CASTGCCookie"/>
         	<header name="CASTGC" scope="transport" expression="$ctx:CASTGC"/>
         	<property name="Set-Cookie" scope="transport" action="remove"/>

